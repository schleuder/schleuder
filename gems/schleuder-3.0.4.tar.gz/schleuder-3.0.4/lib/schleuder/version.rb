module Schleuder
  VERSION = '3.0.4'
end
