module Schleuder
  VERSION = '3.0.3'
end
