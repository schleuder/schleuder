module Schleuder
  VERSION = '3.1.2'
end
