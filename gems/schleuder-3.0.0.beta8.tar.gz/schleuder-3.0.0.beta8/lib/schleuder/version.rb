module Schleuder
  VERSION = '3.0.0.beta8'
end
