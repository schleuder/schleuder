module Schleuder
  VERSION = '3.0.0.beta12'
end
