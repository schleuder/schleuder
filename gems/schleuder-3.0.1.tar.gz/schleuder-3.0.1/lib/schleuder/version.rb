module Schleuder
  VERSION = '3.0.1'
end
