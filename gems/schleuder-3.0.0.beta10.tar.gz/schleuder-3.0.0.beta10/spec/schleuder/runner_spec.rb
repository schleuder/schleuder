require 'spec_helper'

describe Schleuder::Runner do

  describe '#run' do
    it 'should parses mail'
  end
end
