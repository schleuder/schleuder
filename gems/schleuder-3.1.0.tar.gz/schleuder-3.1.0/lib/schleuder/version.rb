module Schleuder
  VERSION = '3.1.0'
end
