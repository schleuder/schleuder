module Schleuder
  VERSION = '3.0.2'
end
