module Schleuder
  VERSION = '3.0.0.beta17'
end
