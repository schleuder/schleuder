module Schleuder
  VERSION = '3.0.0.beta16'
end
