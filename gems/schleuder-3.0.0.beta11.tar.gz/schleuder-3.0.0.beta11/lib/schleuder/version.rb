module Schleuder
  VERSION = '3.0.0.beta11'
end
