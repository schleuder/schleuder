module Schleuder
  VERSION = '3.2.1'
end
